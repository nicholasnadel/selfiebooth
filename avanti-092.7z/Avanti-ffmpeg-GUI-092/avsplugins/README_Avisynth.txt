


	AVANTI - Version 0.9.2 - FFmpeg/AviSynth GUI
	============================================

	
	The name of this folder (/avsplugins) is preserved for compatibility
	with older Avanti versions. It is however recommended to copy AviSynth
	(auto-load) plugins to the "plugins" folder at your AviSynth install
	directory.

	This folder is still used to store a number of AviSynth related files
	but the use of the "scripts" and "eq presets" folders is optional.

	This Avanti version by default expects to find AviSynth "SuperEQ" presets
	in a folder named "Equalizer Presets" at your AviSynth install directory.

	If you upgrade a Avanti version and used the "eq presets" sub-folder in
	this folder, you can set the "SuperEQ_path" back to this folder at the
	user "Preferences" (main menu).

	The "SuperEQ" preset examples are part of your AviSynth installation and
	can be found in a zip which is in the "Examples" folder at your AviSynth
	install directory.


	April 2015 - Chris Kevany

	
